## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(oRm)

## -----------------------------------------------------------------------------
engine <- Engine$new(
  drv = RSQLite::SQLite(),
  dbname = ":memory:",
  persist = TRUE  # Optional for in-memory databases
)

## ----eval=FALSE---------------------------------------------------------------
# engine$get_connection()
# engine$list_tables()
# engine$execute("SELECT * FROM users")

## -----------------------------------------------------------------------------
Users <- TableModel$new(
  "users",
  engine,
  id = Column("INTEGER", primary_key = TRUE),
  organization_id = Column("INTEGER"),
  name = Column("TEXT"),
  age = Column('INTEGER', default = 18)
)

## -----------------------------------------------------------------------------
# Simple Users model without complex defaults
Users <- TableModel$new(
    "users",
    engine,
    id = Column("INTEGER", primary_key = TRUE),
    organization_id = Column("INTEGER"),
    name = Column("TEXT"),
    age = Column("INTEGER")
)

## -----------------------------------------------------------------------------
Organization <- engine$model(
  "organizations",
  id = Column("INTEGER", primary_key = TRUE),
  name = Column("TEXT")
)

## -----------------------------------------------------------------------------
Users$create_table()
Users$record(id = 1, name='John')$create()
Users$record(id = 2, name='Jane', age = 35)$create()

## -----------------------------------------------------------------------------
all_users <- Users$read()
young_users <- Users$read(age < 30)

## -----------------------------------------------------------------------------
specific_user <- Users$read(id == 1, .mode = "get")

## -----------------------------------------------------------------------------
Users$record(id = 3, organization_id = 1, name = "Alice")$create()

## -----------------------------------------------------------------------------
alice <- Users$read(id == 3, .mode = "get")
alice$data$name <- "Alicia"
alice$update()

## -----------------------------------------------------------------------------
alice$delete()

## -----------------------------------------------------------------------------
print(alice$data$name)

## -----------------------------------------------------------------------------
define_relationship(
  Users,
  local_key = "organization_id",
  type = "many_to_one",
  related_model = Organization,
  related_key = "id",
  ref = "organization",
  backref = "users"
)

## -----------------------------------------------------------------------------
Organization$create_table()
Organization$record(id = 1, name = "Widgets, Inc")$create()

## -----------------------------------------------------------------------------

Users$record(id = 3, name = 'Alice', organization_id = 1)$create()
alice = Users$read(id == 3, .mode='get')
alice_org <- alice$relationship('organization')
print(alice_org$data$name)

## -----------------------------------------------------------------------------
young_orgs <- Organization$relationship("users", age < 30)
young_orgs

