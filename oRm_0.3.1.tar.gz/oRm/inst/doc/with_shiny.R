## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  eval=FALSE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
# # in global.R =====
# engine <- Engine$new(
#   drv = RSQLite::SQLite(),
#   dbname = ":memory:",
#   persist = TRUE  # Optional for in-memory databases
# )
# 
# Observations <- engine$model(
#     "observations",
#     observer_id = Column('Integer', primary_key = TRUE),
#     plant_subject_id = Column('Integer'),
#     plant_height = Column('Numeric', nullable = FALSE)
# )
# # =====
# 
# # in server.R =====
# observeEvent(input$add_observation, {
#     # observer_id and plant_height are the values from the form inputs
#     observation = Observations$new(
#         observer_id = input$observer_id,
#         plant_subject_id = input$plant_subject_id,
#         plant_height = input$plant_height
#     )
#     observation$create()
#     showNotification("Observation added!")
# })

## -----------------------------------------------------------------------------
# displayed_observations <- reactive({
#     page_no = input$page_no
#     offset = (page_no - 1) * 5  # Assuming 5 observations per page
# 
#     observations = Observations$read(
#         .order_by = list(desc(observer_id)),
#         .limit = 5,
#         .offset = offset
#         )
# 
#     return(observations)
# })
# 
# output$observation_cards <- renderUI({
#     observations = displayed_observations()
#     tagList(
#         lapply(observations, function(observation) {
#             card(
#                 card_title(paste("Plant ID:", observation$data$plant_subject_id)),
#                 card_body(
#                     paste("Observer ID:", observation$data$observer_id),
#                     paste("Plant Height:", observation$data$plant_height)
#                     )
#             )
#         })
#     )
# })

## -----------------------------------------------------------------------------
# Users <- engine$model(
#     "users",
#     user_id = Column('Integer', primary_key = TRUE),
#     user_name = Column('String', nullable = FALSE)
# )
# 
# observeEvent(input$check_options, {
# 
#     users = Users$read()
#     choices = setNames(
#         sapply(users, function(user) user$data$user_id),
#         sapply(users, function(user) user$data$user_name)
#     )
# 
#     updateSelectInput(session, "user_id", choices = choices)
# 
# })

## -----------------------------------------------------------------------------
# observeEvent(input$add_observation, {
#     # observer_id and plant_height are the values from the form inputs
# 
#     with(engine, {
#         observation = Observations$new(
#             observer_id = input$observer_id,
#             plant_subject_id = input$plant_subject_id,
#             plant_height = input$plant_height
#         )
#         observation$create()
#         # All changes are automatically committed if no errors occur
#     })
# 
#     showNotification("Observation added!")
# })

## -----------------------------------------------------------------------------
# # Setup a model with an auto-incrementing column
# Observations <- engine$model(
#     "observations",
#     id = Column('Serial', primary_key = TRUE),  # Auto-incrementing ID
#     observer_id = Column('Integer'),
#     plant_subject_id = Column('Integer'),
#     plant_height = Column('Numeric', nullable = FALSE),
#     timestamp = Column('Timestamp', default = function() Sys.time())
# )
# 
# # Track observation count in a reactive value
# observation_count <- reactiveVal(0)
# 
# observeEvent(input$add_observation, {
#     with.Engine(engine, {
#         # Create record with flush_record = TRUE to get the ID immediately
#         observation <- Observations$record(
#             observer_id = input$observer_id,
#             plant_subject_id = input$plant_subject_id,
#             plant_height = input$plant_height
#         )
# 
#         # This returns the ID immediately, even before commit
#         observation$create(flush_record = TRUE)
# 
#         # Now we can use the ID for UI updates
#         current_id <- observation$data$id
#         observation_count(current_id)
# 
#         # And for related records
#         ObservationNotes$record(
#             observation_id = current_id,
#             note = input$notes
#         )$create()
#     })
# 
#     # Show feedback with the new observation ID
#     showNotification(paste("Added observation #", observation_count()))
# 
#     # Update a plot or table with the new data
#     output$observation_plot <- renderPlot({
#         # Plot using the latest observation count
#         plot_observations(limit = observation_count())
#     })
# })

