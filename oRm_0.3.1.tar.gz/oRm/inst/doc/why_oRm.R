## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----message = FALSE----------------------------------------------------------
library(DBI)
library(dplyr)
library(dbplyr)

con <- dbConnect(RSQLite::SQLite(), ":memory:")

# Create the table using a data.frame and dbWriteTable
initial_data <- tibble::tibble(
  observer_id = 1L,
  plant_id = 101L,
  measurement_date = as.Date("2025-07-30"),
  measurement_value = 14.2
)

dbWriteTable(con, "measurements", initial_data)

# ===== table setup complete =====

# Add another row later
new_row <- tibble::tibble(
  observer_id = 2L,
  plant_id = 102L,
  measurement_date = as.Date("2025-07-31"),
  measurement_value = 15.8
)

DBI::dbAppendTable(con, "measurements", new_row)

# View the table
tbl(con, "measurements") |>
  filter(observer_id == 2) |>
  collect()


## -----------------------------------------------------------------------------
# You have to find the row and update it manually using SQL
dbExecute(con, "
  UPDATE measurements
  SET measurement_value = 8.15
  WHERE observer_id = 2
")
dbGetQuery(con, 'SELECT * FROM measurements WHERE observer_id = 2')

# Or if we stay are strinct about staying in dbplyr, we might do something like this:

new_tab = tbl(con, "measurements") |>
    mutate(
        measurement_value  = case_when(
            observer_id == 2 ~ 8.15,
            TRUE ~ measurement_value
        )
    ) |>
    collect()

dbWriteTable(con, "measurements", new_tab, overwrite = TRUE)

## -----------------------------------------------------------------------------
library(oRm)

engine <- Engine$new(
  drv = RSQLite::SQLite(),
  dbname = ":memory:",
  persist = TRUE
)

Measurement <- engine$model(
  "measurements",
  id = Column("INTEGER", primary_key = TRUE),
  observer_id = Column("INTEGER"),
  plant_id = ForeignKey("INTEGER", references = 'plants.id'),  # we'll define this table shortly

  measurement_date = Column("DATE"),
  measurement_value = Column("REAL")
)

Measurement$create_table()

# ===== table setup complete =====

# Add a few observations
m1 = Measurement$record(
  observer_id = 1,
  plant_id = 101,
  measurement_date = as.Date("2025-07-30"),
  measurement_value = 14.2
)$create()

m2 = Measurement$record(
  observer_id = 1,
  plant_id = 101,
  measurement_date = as.Date("2025-08-15"),
  measurement_value = 16.0
)$create()

m3 = Measurement$record(
  observer_id = 2,
  plant_id = 102,
  measurement_date = as.Date("2025-07-31"),
  measurement_value = 15.8
)$create()

m1

## -----------------------------------------------------------------------------
p2 = Measurement$read(observer_id == 2, .mode='get')
p2$update(measurement_value = 8.15)
p2

## -----------------------------------------------------------------------------
Plants <- engine$model(
    "plants",
    id = Column("INTEGER", primary_key = TRUE),
    plant_type = Column("TEXT")
)
Plants$create_table()

# and we'll make a handful of plant records
Plants$record(id = 101, plant_type = "pea")$create()
Plants$record(id = 102, plant_type = "potato")$create()
Plants$record(id = 103, plant_type = "pea")$create()

## -----------------------------------------------------------------------------
define_relationship(
    local_model = Plants,
    local_key = "id",
    type = "one_to_many",
    related_model = Measurement,
    related_key = "plant_id",
    ref = "measurements",
    backref = "plant"
)

## -----------------------------------------------------------------------------
p101 = Plants$read(id == 101, .mode='get')
p101$relationship('measurements')

## -----------------------------------------------------------------------------
p101$relationship('measurements', measurement_value < 15.0)

