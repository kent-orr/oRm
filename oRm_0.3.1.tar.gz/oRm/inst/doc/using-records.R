## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(oRm)
engine <- Engine$new(
  drv = RSQLite::SQLite(),
  dbname = ":memory:",
  persist = TRUE
)
Classes <- engine$model(
    tablename = "classes", 
    id = Column('INTEGER', primary_key = TRUE),
    subject = Column('TEXT'),
    teacher_id = ForeignKey('INTEGER', references = 'teachers.id'),
    grade_average = Column('NUMBER', default = \(x) rnorm(1, 80, 10))
)
Classes$create_table()

for (i in 1:10) {
    Classes$record(
        id = i, 
        subject = ifelse(i %% 2 == 0, "Math", "Science"),
        teacher_id = ifelse(i %% 2 == 0, 1, 2)
    )$create()
}

## -----------------------------------------------------------------------------
english = Classes$record(
    id = 11, 
    subject = "English", 
    teacher_id = 2, 
    grade_average = 85
)
english

## -----------------------------------------------------------------------------
english$create(flush_record = NULL)

## -----------------------------------------------------------------------------
english$data$grade_average = 90
english$update()
Classes$read(id==11, .mode='get')

## -----------------------------------------------------------------------------
english$update(grade_average = 91)
Classes$read(id==11, .mode='get')

## -----------------------------------------------------------------------------
e_data = list(grade_average = 92, teacher_id = 1)
english$update(.data = e_data)
Classes$read(id==11, .mode='get')

## -----------------------------------------------------------------------------
english$delete()
Classes$read(!subject %in% c("Math", "Science"), .mode='one_or_none')

