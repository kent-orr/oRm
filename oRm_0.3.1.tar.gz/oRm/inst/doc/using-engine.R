## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(oRm)

engine <- Engine$new(
  drv = RSQLite::SQLite(),
  dbname = ":memory:",
  persist = TRUE
)

engine

## ----eval=FALSE---------------------------------------------------------------
# 
# # Run a raw SQL statement
# engine$execute("CREATE TABLE things (id INTEGER PRIMARY KEY, name TEXT)")
# 
# # Retrieve a result
# df <- engine$get_query("SELECT * FROM things")
# 
# 

## ----eval=FALSE---------------------------------------------------------------
# with(engine, {
#   user = Users$record(name = "John Doe")
#   user$create()
# })

## ----eval=FALSE---------------------------------------------------------------
# with(engine, {
#   user = Users$record(name = "Jane Doe")
#   tryCatch({
#     user$create()
#   }, error = function(e) {
#     print(paste("An error occurred:", e$message))
#     rollback()
#   })
#   commit()
# }, auto_commit = FALSE)
# 

