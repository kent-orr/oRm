## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(oRm)
engine <- Engine$new(
  drv = RSQLite::SQLite(),
  dbname = ":memory:",
  persist = TRUE
)
Classes <- engine$model(
    tablename = "classes", 
    id = Column('INTEGER', primary_key = TRUE),
    subject = Column('TEXT'),
    teacher_id = ForeignKey('INTEGER', references = 'teachers.id')
)
Classes$create_table(overwrite=T)

set.seed(100)
Students <- engine$model(
    tablename = "students", 
    id = Column('INTEGER', primary_key = TRUE),
    name = Column('TEXT'),
    class_id = ForeignKey('INTEGER', references = 'classes.id'),
    grade = Column('NUMBER', default = \(x) round(rnorm(1, 85, 5)))
)
Students$create_table(overwrite=T)


for (i in 1:10) {
    Classes$record(
        id = i, 
        subject = ifelse(i %% 2 == 0, "Math", "Science"),
        teacher_id = ifelse(i %% 2 == 0, 1, 2)
    )$create()
}
Classes$read(.limit = 3)

student_names <- c("Alice", "Bob", "Charlie", "Diana", "Eve", "Frank", "Grace", "Henry", "Ivy", "Jack")
for (i in 1:100) {
    Students$record(
        id = i, 
        name = paste(sample(student_names, 1), i),
        class_id = sample(1:10, 1)
    )$create()
}
Students$read(.limit = 3)


## -----------------------------------------------------------------------------
class_tbl <- Classes$tbl()
student_tbl <- Students$tbl()

dplyr::left_join(class_tbl, student_tbl, by = c(id = "class_id")) |>
    dplyr::filter(id == 1) |>
    dplyr::collect()

## -----------------------------------------------------------------------------
define_relationship(
    local_model = Classes, 
    local_key = 'id',
    type = 'one_to_many',
    related_model = Students, 
    related_key = 'class_id',
    ref = 'students',
    backref = 'class'
)

## -----------------------------------------------------------------------------
class1 = Classes$read(id == 1, .mode='get')
class1_students = class1$relationship('students')
class1_students |> sapply(\(x) paste(
    x$data$name, round(x$data$grade), sep = ': '))

# let's go ahead and apply that curve to the grades
for (student in class1_students) {
    student$data$grade <- student$data$grade + 3
    student$update()
}

class1_students |> sapply(\(x) paste(
    x$data$name, round(x$data$grade), sep = ': '))


## -----------------------------------------------------------------------------
class1_students[[1]]$relationship('class')

## -----------------------------------------------------------------------------
class1$relationship('students', grade < 87)

## -----------------------------------------------------------------------------
set.seed(100)
Teachers <- engine$model(
    tablename = "teachers", 
    id = Column('INTEGER', primary_key = TRUE),
    name = Column('TEXT')
)
Teachers$create_table(overwrite=T)

for (i in 1:3) {
    Teachers$record(id = i)$create()
}
Teachers$read()[[1]]


set.seed(100)
TeacherAssignments <- engine$model(
    tablename = "teacher_assignments", 
    id = Column('INTEGER', primary_key = TRUE),
    teacher_id = ForeignKey('INTEGER', references = 'teachers.id'),
    class_id = ForeignKey('INTEGER', references = 'classes.id')
)

TeacherAssignments$create_table(overwrite=T)

for (i in 1:length(Classes$read())) {
    TeacherAssignments$record(
        teacher_id = sample(1:3, 1),
        class_id = i
    )$create()
} 
TeacherAssignments$read()[1]


## -----------------------------------------------------------------------------
define_relationship(
    local_model = Teachers, 
    local_key = 'id',
    type = 'one_to_many',
    related_model = TeacherAssignments,
    related_key = 'teacher_id',
    ref = 'teacher_assignments',
    backref = 'teacher'
)

define_relationship(
    local_model = TeacherAssignments, 
    local_key = 'class_id',
    type ='one_to_one',
    related_model = Classes,
    related_key = 'id',
    ref = 'class',
    backref = 'teacher_assignment'
)
    

## -----------------------------------------------------------------------------
teacher <- Teachers$read(id == 3, .mode='get')

# teacher$relationship('teacher_assignments') |>
#     lapply(\(x) x$relationship('class')) |>
#     lapply(\(x) x$relationship('students'))

bslib::card(
    bslib::card_title(teacher$data$name),
    bslib::card_body(
        teacher$relationship('teacher_assignments') |>
            lapply(\(x) {
                class = x$relationship('class')
                bslib::card(max_height = '800px',
                    bslib::card_title(class$data$subject),
                    bslib::card_body(
                        class$relationship('students') |>
                            lapply(\(x) htmltools::tags$p(paste(x$data$name, round(x$data$grade))))
                    
                    )
                )
            })
    )
)

