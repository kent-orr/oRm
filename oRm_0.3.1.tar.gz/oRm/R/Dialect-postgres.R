#' @describeIn check_schema_exists Check if a schema exists for PostgreSQL.
check_schema_exists.postgres <- function(x, .schema) {
  if (is.null(.schema)) return(TRUE)

  conn <- NULL
  if (inherits(x, "Engine")) {
    conn <- x$get_connection()
  } else if (inherits(x, "TableModel")) {
    conn <- x$engine$get_connection()
  }

  if (is.null(conn) || !DBI::dbIsValid(conn)) {
    return(FALSE)
  }

  sql <- paste0("SELECT 1 FROM pg_namespace WHERE nspname = ", DBI::dbQuoteLiteral(conn, .schema))
  exists <- FALSE
  try({
    res <- DBI::dbGetQuery(conn, sql)
    exists <- NROW(res) > 0
  }, silent = TRUE)
  exists
}

#' @rdname flush  
#' @usage \method{flush}{postgres}(x, table, data, con, commit = TRUE, ...)
#' @description Insert a row and return the inserted record using PostgreSQL's RETURNING clause.
flush.postgres <- function(x, table, data, con, commit = TRUE, ...) {
  # Build the insert SQL
  data <- data[!vapply(data, is.null, logical(1))]
  tbl_expr <- dbplyr::ident_q(table)
  fields <- names(data)

  # Convert data values to proper format for SQL, handling Date/POSIXct objects
  formatted_values <- sapply(data, function(x) {
    if (inherits(x, "Date")) {
      as.character(x)
    } else if (inherits(x, "POSIXt")) {
      format(x, "%Y-%m-%d %H:%M:%S")
    } else {
      x
    }
  })
  
  values_sql <- paste0("(", paste(DBI::dbQuoteLiteral(con, formatted_values), collapse = ", "), ")")
  field_sql <- paste(DBI::dbQuoteIdentifier(con, fields), collapse = ", ")

  sql <- paste0(
    "INSERT INTO ", tbl_expr, " (", field_sql, ") VALUES ", values_sql,
    " RETURNING *"
  )

  # Just execute the query and return the result
  # Let the caller handle transaction management
  result <- DBI::dbGetQuery(con, sql)
  
  return(result)
}

#' @describeIn qualify Add the schema prefix to unqualified table names for PostgreSQL.
qualify.postgres <- function(x, tablename, .schema) {
  if (!grepl("\\.", tablename) && !is.null(.schema)) {
    paste(.schema, tablename, sep = ".")
  } else {
    tablename
  }
}

#' @describeIn set_schema PostgreSQL applies schema via search_path.
set_schema.postgres <- function(x, .schema) {
    if (is.null(.schema)) return(invisible(NULL))
    conn <- NULL
    if (inherits(x, "Engine")) {
        conn <- x$conn
    } else if (inherits(x, "TableModel")) {
        conn <- x$engine$conn
    }
 
    stopifnot("invalid connection in set_schema.postgres" = !is.null(conn) && DBI::dbIsValid(conn)) 
    
    sql <- paste0("SET search_path TO ", DBI::dbQuoteIdentifier(conn, .schema))
    execute_sql(x, conn, sql)
    
    invisible(NULL)
}

#' @describeIn create_schema Create the schema for PostgreSQL.
#'   Suppresses notices when the schema already exists.
create_schema.postgres <- function(x, .schema) {
    if (is.null(.schema)) stop("Must supply a schema name.", call. = FALSE)
    
    # Get a direct connection without triggering schema setting
    conn <- NULL
    engine <- if (inherits(x, "Engine")) x else x$engine
    
    if (is.null(engine$conn) || !DBI::dbIsValid(engine$conn)) {
        conn <- do.call(DBI::dbConnect, engine$conn_args)
        on.exit(DBI::dbDisconnect(conn), add = TRUE)
    } else {
        conn <- engine$conn
    }
    
    sql <- paste0("CREATE SCHEMA IF NOT EXISTS ", DBI::dbQuoteIdentifier(conn, .schema))
    suppressMessages(DBI::dbExecute(conn, sql))
    invisible(TRUE)
}

#' @describeIn execute_sql Suppress PostgreSQL messages when executing SQL commands.
execute_sql.postgres <- function(x, con, sql) {
    suppressMessages(DBI::dbExecute(con, sql))
}

